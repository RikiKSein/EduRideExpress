package com.example.eduridex;

public class Driver extends User {
    private String licenseNumber;
    private String vehicleInfo;
    private String insuranceDetails;
    private boolean backgroundCheckVerified;

    // Getters and Setters
    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getVehicleInfo() {
        return vehicleInfo;
    }

    public void setVehicleInfo(String vehicleInfo) {
        this.vehicleInfo = vehicleInfo;
    }

    public String getInsuranceDetails() {
        return insuranceDetails;
    }

    public void setInsuranceDetails(String insuranceDetails) {
        this.insuranceDetails = insuranceDetails;
    }

    public boolean isBackgroundCheckVerified() {
        return backgroundCheckVerified;
    }

    public void setBackgroundCheckVerified(boolean backgroundCheckVerified) {
        this.backgroundCheckVerified = backgroundCheckVerified;
    }

}