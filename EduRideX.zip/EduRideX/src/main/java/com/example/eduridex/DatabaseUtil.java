package com.example.eduridex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {

    private static final String URL = "jdbc:sqlite:ridesharing.db";

    public static Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL);
            System.out.println("Successfully connected to the RideSharing database!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public static void initializeDatabase() {
        String dropContractsTable = "DROP TABLE IF EXISTS contracts;";

        String userTable = "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT NOT NULL UNIQUE," +
                "password TEXT NOT NULL," +
                "balance REAL NOT NULL," +
                "userType TEXT NOT NULL" +
                ");";

        String childrenTable = "CREATE TABLE IF NOT EXISTS children (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "parent_id INTEGER NOT NULL," +
                "name TEXT NOT NULL," +
                "age INTEGER NOT NULL," +
                "school TEXT NOT NULL," +
                "pickupLocation TEXT NOT NULL," +
                "dropOffLocation TEXT NOT NULL," +
                "contactInfo TEXT," +
                "FOREIGN KEY (parent_id) REFERENCES users(id)" +
                ");";

        String driversTable = "CREATE TABLE IF NOT EXISTS drivers (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "licenseNumber INT NOT NULL," +
                "vehicleInfo TEXT," +
                "insuranceDetails TEXT," +
                "backgroundCheckVerified BOOLEAN," +
                "licenseImagePath TEXT," +
                "FOREIGN KEY (user_id) REFERENCES users(id)" +
                ");";

        String ridesTable = "CREATE TABLE IF NOT EXISTS rides (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "driver_id INTEGER NOT NULL," +
                "pickupLocation TEXT NOT NULL," +
                "dropOffLocation TEXT NOT NULL," +
                "time TEXT NOT NULL," +
                "availableSeats INTEGER NOT NULL," +
                "FOREIGN KEY (driver_id) REFERENCES drivers(id)" +
                ");";

        String contractsTable = "CREATE TABLE IF NOT EXISTS contracts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "parent_id INTEGER NOT NULL," +
                "driver_id INTEGER NOT NULL," +
                "ride_id INTEGER NOT NULL," +
                "startDate TEXT NOT NULL," +
                "endDate TEXT NOT NULL," +
                "cost REAL NOT NULL," +
                "bookedSeats INTEGER NOT NULL," +
                "FOREIGN KEY (parent_id) REFERENCES users(id)," +
                "FOREIGN KEY (driver_id) REFERENCES drivers(id)," +
                "FOREIGN KEY (ride_id) REFERENCES rides(id)" +
                ");";

        String notificationsTable = "CREATE TABLE IF NOT EXISTS notifications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "recipient_id INTEGER NOT NULL," +
                "message TEXT NOT NULL," +
                "timestamp TEXT NOT NULL," +
                "FOREIGN KEY (recipient_id) REFERENCES users(id)" +
                ");";

        String addLicenseImagePathColumn = "ALTER TABLE drivers ADD COLUMN licenseImagePath TEXT;";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(dropContractsTable);
            stmt.execute(userTable);
            stmt.execute(childrenTable);
            stmt.execute(driversTable);
            stmt.execute(ridesTable);
            stmt.execute(contractsTable);
            stmt.execute(notificationsTable);

            // Try adding the new column if it doesn't exist
            try {
                stmt.execute(addLicenseImagePathColumn);
            } catch (SQLException e) {
                if (!e.getMessage().contains("duplicate column name: licenseImagePath")) {
                    throw e;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
