package com.example.eduridex;

import java.util.ArrayList;
import java.util.List;

public class ParentUser extends User {
    private List<Child> children = new ArrayList<>();

    // Getters and Setters
    public List<Child> getChildren() {
        return children;
    }

    public void addChild(Child child) {
        this.children.add(child);
    }

}
