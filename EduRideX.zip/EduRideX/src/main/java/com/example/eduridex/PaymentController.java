package com.example.eduridex;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.Pane;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.UnaryOperator;

public class PaymentController implements MyController{
    @FXML
    private Label balanceLabel;
    @FXML
    private TextField depositAmountField;
    @FXML
    private TextField paymentAmountField;
    @FXML
    private Label paymentLabel;
    @FXML
    private Button paymentBtn;

    private int userId;
    private String userType;

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        loadBalance();
    }

    @FXML
    public void initialize() {
        // Restrict depositAmountField and paymentAmountField to only accept numbers
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("\\d*")) {
                return change;
            }
            return null;
        };

        TextFormatter<String> depositFormatter = new TextFormatter<>(filter);
        TextFormatter<String> paymentFormatter = new TextFormatter<>(filter);

        depositAmountField.setTextFormatter(depositFormatter);
        paymentAmountField.setTextFormatter(paymentFormatter);


    }

    @FXML
    public void depositFunds() {
        double amount = Double.parseDouble(depositAmountField.getText());
        if (updateBalance(amount)) {
            loadBalance();
            depositAmountField.clear();
        } else {

        }
    }

    @FXML
    public void makePayment() {
        double amount = Double.parseDouble(paymentAmountField.getText());
        if (updateBalance(-amount)) {
            loadBalance();
            paymentAmountField.clear();
        } else {
            // Show error message (not implemented here)
        }
    }

    private void loadBalance() {
        String query = "SELECT balance FROM users WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                balanceLabel.setText("Balance: $" + rs.getDouble("balance"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean updateBalance(double amount) {
        String query = "UPDATE users SET balance = balance + ? WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
