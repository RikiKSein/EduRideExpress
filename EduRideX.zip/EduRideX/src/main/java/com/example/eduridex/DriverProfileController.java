package com.example.eduridex;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DriverProfileController implements MyController {
    @FXML
    private TextField licenseNumberField;
    @FXML
    private TextField vehicleInfoField;
    @FXML
    private TextField insuranceDetailsField;
    @FXML
    private TextField backgroundCheckField;
    @FXML
    private Button updateButton;
    @FXML
    private Button uploadLicenseButton;
    @FXML
    private ImageView licenseImageView;

    private int userId; // Assume this is set when the driver logs in
    private String userType;
    private File selectedFile; // File object to store the selected license image

    // create an alert
    Alert a = new Alert(Alert.AlertType.NONE);

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        loadDriverProfile();
    }

    @FXML
    public void initialize() {
        // This can be empty or can include other initial setup
    }

    @FXML
    public void updateProfile() {
        String licenseNumber = licenseNumberField.getText();
        String vehicleInfo = vehicleInfoField.getText();
        String insuranceDetails = insuranceDetailsField.getText();
        String backgroundCheck = backgroundCheckField.getText();
        String licenseImagePath = selectedFile != null ? selectedFile.getAbsolutePath() : null;

        System.out.println("Updating profile with:");
        System.out.println("License Number: " + licenseNumber);
        System.out.println("Vehicle Info: " + vehicleInfo);
        System.out.println("Insurance Details: " + insuranceDetails);
        System.out.println("Background Check: " + backgroundCheck);
        System.out.println("License Image Path: " + licenseImagePath);

        if (updateDriverProfileInDatabase(userId, licenseNumber, vehicleInfo, insuranceDetails, backgroundCheck, licenseImagePath)) {
            a.setAlertType(Alert.AlertType.CONFIRMATION);
            a.setContentText("Profile updated successfully!");
            a.show();
        } else {
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Failed to update!");
            a.show();
        }
    }

    private boolean updateDriverProfileInDatabase(int userId, String licenseNumber, String vehicleInfo, String insuranceDetails, String backgroundCheck, String licenseImagePath) {
        String query = "UPDATE drivers SET licenseNumber = ?, vehicleInfo = ?, insuranceDetails = ?, backgroundCheckVerified = ?, licenseImagePath = ? WHERE user_id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, licenseNumber);
            pstmt.setString(2, vehicleInfo);
            pstmt.setString(3, insuranceDetails);
            pstmt.setBoolean(4, !backgroundCheck.isEmpty());
            pstmt.setString(5, licenseImagePath);
            pstmt.setInt(6, userId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error updating driver profile: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private void loadDriverProfile() {
        String query = "SELECT licenseNumber, vehicleInfo, insuranceDetails, backgroundCheckVerified, licenseImagePath FROM drivers WHERE user_id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                licenseNumberField.setText(rs.getString("licenseNumber"));
                vehicleInfoField.setText(rs.getString("vehicleInfo"));
                insuranceDetailsField.setText(rs.getString("insuranceDetails"));
                backgroundCheckField.setText(rs.getBoolean("backgroundCheckVerified") ? "Verified" : "");

                String licenseImagePath = rs.getString("licenseImagePath");
                if (licenseImagePath != null) {
                    selectedFile = new File(licenseImagePath);
                    if (selectedFile.exists()) {
                        Image image = new Image(selectedFile.toURI().toString());
                        licenseImageView.setImage(image);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error loading driver profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void uploadLicenseImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        selectedFile = fileChooser.showOpenDialog(uploadLicenseButton.getScene().getWindow());
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            licenseImageView.setImage(image);
        }
    }

    private void resetForm() {
        licenseNumberField.clear();
        vehicleInfoField.clear();
        insuranceDetailsField.clear();
        backgroundCheckField.clear();
        licenseImageView.setImage(null);
        selectedFile = null;
    }
}
