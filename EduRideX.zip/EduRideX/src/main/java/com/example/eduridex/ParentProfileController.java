package com.example.eduridex;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ParentProfileController implements MyController {
    @FXML
    private ListView<String> childrenListView;
    @FXML
    private TextField nameField;
    @FXML
    private TextField ageField;
    @FXML
    private TextField schoolField;
    @FXML
    private TextField pickupLocationField;
    @FXML
    private TextField dropOffLocationField;
    @FXML
    private TextField contactInfoField;

    @FXML
    private Button actionButton;
    @FXML
    private Button deleteButton;

    private int userId;
    private String userType;
    private ObservableList<String> childrenList = FXCollections.observableArrayList();
    private int selectedChildId = -1;

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        loadChildren();
    }

    @FXML
    public void initialize() {
        loadChildren();
    }

    @FXML
    public void handleAction() {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String school = schoolField.getText();
        String pickupLocation = pickupLocationField.getText();
        String dropOffLocation = dropOffLocationField.getText();
        String contactInfo = contactInfoField.getText();

        if (selectedChildId == -1) {
            if (addChildToDatabase(name, age, school, pickupLocation, dropOffLocation, contactInfo)) {
                loadChildren(); // Refresh the list of children after adding a new one
            } else {
                // Handle add child error
            }
        } else {
            if (updateChildInDatabase(selectedChildId, name, age, school, pickupLocation, dropOffLocation, contactInfo)) {
                loadChildren(); // Refresh the list of children after updating
                resetForm();
            } else {
                // Handle update child error
            }
        }
    }

    private boolean addChildToDatabase(String name, int age, String school, String pickupLocation, String dropOffLocation, String contactInfo) {
        String query = "INSERT INTO children (parent_id, name, age, school, pickupLocation, dropOffLocation, contactInfo) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, name);
            pstmt.setInt(3, age);
            pstmt.setString(4, school);
            pstmt.setString(5, pickupLocation);
            pstmt.setString(6, dropOffLocation);
            pstmt.setString(7, contactInfo);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean updateChildInDatabase(int childId, String name, int age, String school, String pickupLocation, String dropOffLocation, String contactInfo) {
        String query = "UPDATE children SET name = ?, age = ?, school = ?, pickupLocation = ?, dropOffLocation = ?, contactInfo = ? WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, school);
            pstmt.setString(4, pickupLocation);
            pstmt.setString(5, dropOffLocation);
            pstmt.setString(6, contactInfo);
            pstmt.setInt(7, childId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean deleteChildFromDatabase(int childId) {
        String query = "DELETE FROM children WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, childId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void loadChildren() {
        String query = "SELECT id, name, age, school, pickupLocation, dropOffLocation, contactInfo FROM children WHERE parent_id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            childrenList.clear();
            while (rs.next()) {
                String childInfo = String.format("Name: %s, Age: %d, School: %s, Pickup: %s, Drop-Off: %s, Contact: %s",
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("school"),
                        rs.getString("pickupLocation"),
                        rs.getString("dropOffLocation"),
                        rs.getString("contactInfo"));
                childrenList.add(childInfo);
            }
            childrenListView.setItems(childrenList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleChildClick(MouseEvent event) {
        String selectedChild = childrenListView.getSelectionModel().getSelectedItem();
        if (selectedChild != null) {
            String[] parts = selectedChild.split(", ");
            nameField.setText(parts[0].split(": ")[1]);
            ageField.setText(parts[1].split(": ")[1]);
            schoolField.setText(parts[2].split(": ")[1]);
            pickupLocationField.setText(parts[3].split(": ")[1]);
            dropOffLocationField.setText(parts[4].split(": ")[1]);
            contactInfoField.setText(parts[5].split(": ")[1]);

            selectedChildId = getChildIdFromDatabase(parts[0].split(": ")[1]);
            actionButton.setText("Update");
        }
    }

    @FXML
    public void handleDelete() {
        if (selectedChildId != -1) {
            if (deleteChildFromDatabase(selectedChildId)) {
                loadChildren(); // Refresh the list of children after deleting
                resetForm();
            } else {
                // Handle delete child error
            }
        }
    }

    private int getChildIdFromDatabase(String name) {
        String query = "SELECT id FROM children WHERE parent_id = ? AND name = ?";
        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, name);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private void resetForm() {
        nameField.clear();
        ageField.clear();
        schoolField.clear();
        pickupLocationField.clear();
        dropOffLocationField.clear();
        contactInfoField.clear();
        actionButton.setText("Add Child");
        selectedChildId = -1;
    }
}
