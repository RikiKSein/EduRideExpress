module com.example.eduridex {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.eduridex to javafx.fxml;
    exports com.example.eduridex;
}