package com.example.eduridex;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class NotificationController implements MyController {
    @FXML
    private ListView<String> notificationListView;

    private ObservableList<String> notificationsList = FXCollections.observableArrayList();
    private int userId;
    private String userType;

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        loadNotifications();
    }

    @FXML
    public void initialize() {
        notificationListView.setItems(notificationsList);
    }

    private void loadNotifications() {
        String query = "SELECT message, timestamp FROM notifications WHERE recipient_id = ? ORDER BY timestamp DESC";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            notificationsList.clear();
            while (rs.next()) {
                String message = rs.getString("message");
                String timestamp = rs.getString("timestamp");
                notificationsList.add(String.format("%s - %s", timestamp, message));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void sendNotification(int recipientId, String message) {
        String query = "INSERT INTO notifications (recipient_id, message, timestamp) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, recipientId);
            pstmt.setString(2, message);
            pstmt.setString(3, LocalDateTime.now().toString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
