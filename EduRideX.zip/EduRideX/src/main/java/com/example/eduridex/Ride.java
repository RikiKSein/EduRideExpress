package com.example.eduridex;

import java.time.LocalDateTime;

class Ride {
    private int id;
    private String pickupLocation;
    private String dropOffLocation;
    private String time;
    private int availableSeats;

    public Ride(int id, String pickupLocation, String dropOffLocation, String time, int availableSeats) {
        this.id = id;
        this.pickupLocation = pickupLocation;
        this.dropOffLocation = dropOffLocation;
        this.time = time;
        this.availableSeats = availableSeats;
    }

    public int getId() {
        return id;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public String getDropOffLocation() {
        return dropOffLocation;
    }

    public String getTime() {
        return time;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }
}


