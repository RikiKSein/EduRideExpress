package com.example.eduridex;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class RideSearchController implements MyController {
    @FXML
    private ComboBox pickupLocationField;
    @FXML
    private ComboBox dropOffLocationField;
    @FXML
    private DatePicker dateField;
    @FXML
    private ListView<String> ridesListView;
    @FXML
    private Button selectRideButton;

    // Fields for adding new rides
    @FXML
    private Label addRideLabel;
    @FXML
    private TextField newPickupLocationField;
    @FXML
    private TextField newDropOffLocationField;
    @FXML
    private DatePicker newDateField;
    @FXML
    private TextField newTimeField;
    @FXML
    private TextField newSeatsField;
    @FXML
    private Button addRideButton;

    private ObservableList<String> ridesList = FXCollections.observableArrayList();
    private int selectedRideId = -1;
    private int userId = -1; // Assume this is set when the driver logs in
    private String userType = "Parent";
    @FXML
    public void initialize() {
        ridesListView.setItems(ridesList);
    }

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        if (userType.equals("Driver")){
            showAddRideSection(true);
        }
    }


    @FXML
    public void searchRides() {
        String pickupLocation = (String) pickupLocationField.getValue();
        String dropOffLocation = (String) dropOffLocationField.getValue();
        LocalDate date = dateField.getValue();

        List<Ride> rides = searchRidesInDatabase(pickupLocation, dropOffLocation, date);
        displayRides(rides);
    }

    private List<Ride> searchRidesInDatabase(String pickupLocation, String dropOffLocation, LocalDate date) {
        List<Ride> rides = new ArrayList<>();
        String query = "SELECT id, pickupLocation, dropOffLocation, time, availableSeats FROM rides " +
                "WHERE pickupLocation = ? AND dropOffLocation = ? AND DATE(time) = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, pickupLocation);
            pstmt.setString(2, dropOffLocation);
            pstmt.setString(3, date.toString());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String pickup = rs.getString("pickupLocation");
                String dropOff = rs.getString("dropOffLocation");
                String time = rs.getString("time");
                int availableSeats = rs.getInt("availableSeats");

                rides.add(new Ride(id, pickup, dropOff, time, availableSeats));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rides;
    }

    private void displayRides(List<Ride> rides) {
        ridesList.clear();
        for (Ride ride : rides) {
            ridesList.add(String.format("Pickup: %s, Drop-Off: %s, Time: %s, Seats: %d",
                    ride.getPickupLocation(), ride.getDropOffLocation(), ride.getTime(), ride.getAvailableSeats()));
        }
    }

    @FXML
    public void handleRideClick(MouseEvent event) {
        String selectedRide = ridesListView.getSelectionModel().getSelectedItem();
        if (selectedRide != null) {
            selectedRideId = getRideIdFromString(selectedRide);
            selectRideButton.setDisable(false);
        }
    }

    @FXML
    public void selectRide() {
        if (selectedRideId != -1) {

            System.out.println("Selected Ride ID: " + selectedRideId);
        }
    }

    private int getRideIdFromString(String rideString) {
        String[] parts = rideString.split(", ");
        String time = parts[2].split(": ")[1];
        String query = "SELECT id FROM rides WHERE pickupLocation = ? AND dropOffLocation = ? AND time = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, parts[0].split(": ")[1]);
            pstmt.setString(2, parts[1].split(": ")[1]);
            pstmt.setString(3, time);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @FXML
    public void addRide() {
        String pickupLocation = newPickupLocationField.getText();
        String dropOffLocation = newDropOffLocationField.getText();
        LocalDate date = newDateField.getValue();
        LocalTime time = LocalTime.parse(newTimeField.getText());
        int availableSeats = Integer.parseInt(newSeatsField.getText());

        if (addRideToDatabase(pickupLocation, dropOffLocation, date, time, availableSeats)) {
            clearAddRideFields();
        } else {
            // Show error message (not implemented here)
        }
    }

    private boolean addRideToDatabase(String pickupLocation, String dropOffLocation, LocalDate date, LocalTime time, int availableSeats) {
        String query = "INSERT INTO rides (driver_id, pickupLocation, dropOffLocation, time, availableSeats) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, pickupLocation);
            pstmt.setString(3, dropOffLocation);
            pstmt.setString(4, date.atTime(time).toString());
            pstmt.setInt(5, availableSeats);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAddRideSection(boolean visible) {
        addRideLabel.setVisible(visible);
        newPickupLocationField.setVisible(visible);
        newDropOffLocationField.setVisible(visible);
        newDateField.setVisible(visible);
        newTimeField.setVisible(visible);
        newSeatsField.setVisible(visible);
        addRideButton.setVisible(visible);
    }

    private void clearAddRideFields() {
        newPickupLocationField.clear();
        newDropOffLocationField.clear();
        newDateField.setValue(null);
        newTimeField.clear();
        newSeatsField.clear();
    }
}

