package com.example.eduridex;

import java.util.HashMap;
import java.util.Map;

public class Authentication {
    private static Map<String, String> userDatabase = new HashMap<>();

    static {
        // Example data
        userDatabase.put("user", "pass");
    }

    public static boolean login(String username, String password) {
        return userDatabase.containsKey(username) && userDatabase.get(username).equals(password);
    }

    public static void register(String username, String password) {
        userDatabase.put(username, password);
    }
}
