package com.example.eduridex;

public interface MyController {

    public void setUserId(int userId, String userType);

}
