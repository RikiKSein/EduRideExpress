package com.example.eduridex;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class ContractController implements MyController {
    @FXML
    private ListView<String> contractsListView;
    @FXML
    private TextField pickupLocationField;
    @FXML
    private TextField dropOffLocationField;
    @FXML
    private ComboBox<String> driverComboBox;
    @FXML
    private ComboBox<String> rideComboBox;
    @FXML
    private ComboBox<String> durationComboBox;
    @FXML
    private Button searchDriversButton;
    @FXML
    private Button signUpButton;
    @FXML
    private Label addContractLabel;

    private ObservableList<String> contractsList = FXCollections.observableArrayList();
    private int userId;
    private String userType;

    public void setUserId(int userId, String userType) {
        this.userId = userId;
        this.userType = userType;
        loadContracts();
        if ("Parent".equals(userType)) {
            showAddContractSection(true);
        }
    }

    @FXML
    public void initialize() {
        contractsListView.setItems(contractsList);
        driverComboBox.setOnAction(e -> loadRides());
    }

    private void loadContracts() {
        List<String> contracts = new ArrayList<>();
        String query = userType.equals("Parent") ?
                "SELECT * FROM contracts WHERE parent_id = ?" :
                "SELECT * FROM contracts WHERE driver_id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String contractInfo = String.format("Contract ID: %d, Start Date: %s, End Date: %s, Seats: %d, Cost: %.2f",
                        rs.getInt("id"),
                        rs.getString("startDate"),
                        rs.getString("endDate"),
                        rs.getInt("bookedSeats"),
                        rs.getDouble("cost"));
                contracts.add(contractInfo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        contractsList.setAll(contracts);
    }

    private void showAddContractSection(boolean visible) {
        addContractLabel.setVisible(visible);
        pickupLocationField.setVisible(visible);
        dropOffLocationField.setVisible(visible);
        searchDriversButton.setVisible(visible);
        driverComboBox.setVisible(visible);
        rideComboBox.setVisible(visible);
        durationComboBox.setVisible(visible);
        signUpButton.setVisible(visible);
    }

    @FXML
    public void loadDrivers() {
        String pickupLocation = pickupLocationField.getText();
        String dropOffLocation = dropOffLocationField.getText();

        if (pickupLocation.isEmpty() || dropOffLocation.isEmpty()) {

            return;
        }

        String query = "SELECT DISTINCT u.username FROM users u JOIN rides r ON u.id = r.driver_id " +
                "WHERE u.userType = 'Driver' AND r.pickupLocation = ? AND r.dropOffLocation = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, pickupLocation);
            pstmt.setString(2, dropOffLocation);
            ResultSet rs = pstmt.executeQuery();

            List<String> drivers = new ArrayList<>();
            while (rs.next()) {
                drivers.add(rs.getString("username"));
            }
            driverComboBox.setItems(FXCollections.observableArrayList(drivers));
            driverComboBox.setDisable(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadRides() {
        String selectedDriver = driverComboBox.getValue();
        if (selectedDriver == null) return;

        String query = "SELECT r.id, r.pickupLocation, r.dropOffLocation, r.time, r.availableSeats " +
                "FROM rides r JOIN users u ON r.driver_id = u.id " +
                "WHERE u.username = ? AND r.pickupLocation = ? AND r.dropOffLocation = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, selectedDriver);
            pstmt.setString(2, pickupLocationField.getText());
            pstmt.setString(3, dropOffLocationField.getText());
            ResultSet rs = pstmt.executeQuery();

            List<String> rides = new ArrayList<>();
            while (rs.next()) {
                String rideInfo = String.format("Ride ID: %d, Time: %s, Seats: %d",
                        rs.getInt("id"),
                        rs.getString("time"),
                        rs.getInt("availableSeats"));
                rides.add(rideInfo);
            }
            rideComboBox.setItems(FXCollections.observableArrayList(rides));
            rideComboBox.setDisable(false);
            signUpButton.setDisable(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void signUpForContract() {
        String selectedRide = rideComboBox.getValue();
        if (selectedRide == null) return;

        int rideId = Integer.parseInt(selectedRide.split(", ")[0].split(": ")[1]);
        String duration = durationComboBox.getValue();
        LocalDateTime startDate = LocalDateTime.now();
        LocalDateTime endDate = calculateEndDate(startDate, duration);
        int availableSeats = getAvailableSeats(rideId);

        if (availableSeats <= 0) {
            // Show error message: No available seats
            return;
        }

        double cost = calculateCost(duration, 1); // Assuming 1 seat per contract
        if (addContractToDatabase(rideId, 1, startDate, endDate, cost) && updateBalances(cost, rideId)) {
            loadContracts();
        } else {
            System.out.println("Contract not added!");
            // Show error message (not implemented here)
        }
    }

    private LocalDateTime calculateEndDate(LocalDateTime startDate, String duration) {
        switch (duration) {
            case "Weekly":
                return startDate.plusWeeks(1);
            case "Monthly":
                return startDate.plusMonths(1);
            case "3-Monthly":
                return startDate.plusMonths(3);
            case "Yearly":
                return startDate.plusYears(1);
            default:
                throw new IllegalArgumentException("Unknown duration: " + duration);
        }
    }

    private double calculateCost(String duration, int seats) {
        double baseCost;
        switch (duration) {
            case "Weekly":
                baseCost = 50.0;
                break;
            case "Monthly":
                baseCost = 180.0;
                break;
            case "3-Monthly":
                baseCost = 500.0;
                break;
            case "Yearly":
                baseCost = 2000.0;
                break;
            default:
                throw new IllegalArgumentException("Unknown duration: " + duration);
        }
        return baseCost * seats;
    }

    private boolean addContractToDatabase(int rideId, int seats, LocalDateTime startDate, LocalDateTime endDate, double cost) {
        String query = "INSERT INTO contracts (parent_id, driver_id, ride_id, startDate, endDate, bookedSeats, cost) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, getDriverId(rideId));
            pstmt.setInt(3, rideId);
            pstmt.setString(4, startDate.toString());
            pstmt.setString(5, endDate.toString());
            pstmt.setInt(6, seats);
            pstmt.setDouble(7, cost);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean updateBalances(double cost, int rideId) {
        if (!updateBalance(userId, -cost)) return false;
        int driverId = getDriverId(rideId);
        if (!updateBalance(driverId, cost)) return false;
        if (!updateAvailableSeats(rideId)) return false;
        return true;
    }

    private boolean updateBalance(int userId, double amount) {
        String query = "UPDATE users SET balance = balance + ? WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private int getDriverId(int rideId) {
        String query = "SELECT driver_id FROM rides WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, rideId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("driver_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getAvailableSeats(int rideId) {
        String query = "SELECT availableSeats FROM rides WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, rideId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("availableSeats");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private boolean updateAvailableSeats(int rideId) {
        String query = "UPDATE rides SET availableSeats = availableSeats - 1 WHERE id = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, rideId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
