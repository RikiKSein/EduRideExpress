package com.example.eduridex;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label statusLabel;

    private String userType;
    private int userId;

    @FXML
    public void login() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (authenticate(username, password)) {
            statusLabel.setText("Welcome back to your account!");
            loadMainLayout();
        } else {
            statusLabel.setText("Login failed!");
        }
    }

    private boolean authenticate(String username, String password) {
        String query = "SELECT id, userType FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                this.userId = rs.getInt("id");
                this.userType = rs.getString("userType");
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void loadMainLayout() {
        System.out.println("Type: " + this.userType + " ID: " + this.userId);
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("main-view.fxml"));
            Parent mainLayout = loader.load();
            MainLayoutController controller = loader.getController();
            controller.setUserTypeAndId(this.userType, this.userId); // Pass the user type and ID to the main layout controller

            Scene mainScene = new Scene(mainLayout);

            // Get the current stage
            Stage primaryStage = (Stage) usernameField.getScene().getWindow();

            primaryStage.setScene(mainScene);
            primaryStage.setMaximized(true);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void register() {
        loadLayout("registration-view.fxml");
    }

    private void loadLayout(String page_name) {
        try {
            Parent mainLayout = FXMLLoader.load(LoginController.class.getResource(page_name));
            Scene mainScene = new Scene(mainLayout);

            // Get the current stage
            Stage primaryStage = (Stage) usernameField.getScene().getWindow();

            // Set the new scene
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
