package com.example.eduridex;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;

public class MainLayoutController {

    @FXML
    private AnchorPane mainContent;

    private String userType;
    private int userId;

    public void setUserTypeAndId(String userType, int userId) {
        this.userType = userType;
        this.userId = userId;
        loadProfileView();
    }

    public void loadProfileView() {
        System.out.println("Loading profile view");
        System.out.println(userType);
        if ("Parent".equals(userType)) {
            loadParentProfileView();
        } else if ("Driver".equals(userType)) {
            loadDriverProfileView();
        }
    }

    private void loadParentProfileView() {
        loadView("profile-parent.fxml");
    }

    private void loadDriverProfileView() {
        loadView("profile-driver.fxml");
    }


    public void loadPaymentView() {
        loadView("payment-view.fxml");
    }

    public void loadRideView() {
        loadView("ride-view.fxml");
    }

    public void loadContractView() {
        loadView("contract-view.fxml");
    }

    public void loadNotificationView() {
        loadView("notifications-view.fxml");
    }

    public void logout(){
        Parent mainLayout = null;
        try {
            mainLayout = FXMLLoader.load(MainLayoutController.class.getResource("login-view.fxml"));
            Scene mainScene = new Scene(mainLayout);

            // Get the current stage
            Stage primaryStage = (Stage) mainContent.getScene().getWindow();

            // Set the new scene
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadView(String fxmlFile) {
        System.out.println("Loading " + fxmlFile);

        try {
            FXMLLoader loader = new FXMLLoader(MainLayoutController.class.getResource(fxmlFile));
            Node node = loader.load();
            MyController controller = loader.getController();
            controller.setUserId(userId, userType); // Pass the driver ID to the controller
            mainContent.getChildren().setAll(node);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
