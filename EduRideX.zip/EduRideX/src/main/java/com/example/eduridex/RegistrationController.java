package com.example.eduridex;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegistrationController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField initialBalanceField;

    @FXML
    private ComboBox<String> userTypeComboBox;

    @FXML
    private Label statusLabel;

    @FXML
    public void register() {
        System.out.println("Register button clicked");

        String username = usernameField.getText();
        String password = passwordField.getText();
        String initialBalanceText = initialBalanceField.getText();
        String userType = userTypeComboBox.getValue();

        // Basic input validation
        if (username.isEmpty() || password.isEmpty() || initialBalanceText.isEmpty() || userType == null) {
            statusLabel.setText("Please fill in all fields");
            return;
        }

        if (password.length() <  8) {
            statusLabel.setText("Password must be at least 8 characters long.");
            return;
        }

        double initialBalance;
        try {
            initialBalance = Double.parseDouble(initialBalanceText);
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid initial balance");
            return;
        }

        if (createUser(username, password, initialBalance, userType)) {
            statusLabel.setText("Registration successful!");
            loadLoginLayout();
        } else {
            statusLabel.setText("Registration failed!");
        }
    }

    @FXML
    public void login() {
        loadLoginLayout();
    }

    private boolean createUser(String username, String password, double initialBalance, String userType) {
        String userQuery = "INSERT INTO users (username, password, balance, userType) VALUES (?, ?, ?, ?)";
        String driverQuery = "INSERT INTO drivers (user_id, licenseNumber) VALUES (?, '')"; // Assuming licenseNumber will be updated later

        try (Connection conn = DatabaseUtil.connect();
             PreparedStatement userPstmt = conn.prepareStatement(userQuery, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement driverPstmt = conn.prepareStatement(driverQuery)) {

            // Insert into users table
            userPstmt.setString(1, username);
            userPstmt.setString(2, password);
            userPstmt.setDouble(3, initialBalance);
            userPstmt.setString(4, userType);
            userPstmt.executeUpdate();

            // Get generated user ID
            ResultSet rs = userPstmt.getGeneratedKeys();
            if (rs.next()) {
                int userId = rs.getInt(1);
                if ("Driver".equals(userType)) {
                    // Insert into drivers table
                    driverPstmt.setInt(1, userId);
                    driverPstmt.executeUpdate();
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void loadLoginLayout() {
        try {
            Parent mainLayout = FXMLLoader.load(getClass().getResource("login-view.fxml"));
            Scene mainScene = new Scene(mainLayout);

            // Get the current stage
            Stage primaryStage = (Stage) usernameField.getScene().getWindow();

            // Set the new scene
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
