package com.example.eduridex;

import java.time.LocalDateTime;

public class Contract {
    private ParentUser parent;
    private Driver driver;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private double cost;
    private int bookedSeats;

    // Getters and Setters
    public ParentUser getParent() {
        return parent;
    }

    public void setParent(ParentUser parent) {
        this.parent = parent;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(int bookedSeats) {
        this.bookedSeats = bookedSeats;
    }
}
